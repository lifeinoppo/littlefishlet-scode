define(["./Get", "./Post"], function(Get, Post) {
    return {
        Get: Get,
        Post: Post,
    };
});
