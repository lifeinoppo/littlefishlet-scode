var event = require( 'events' ).EventEmitter;

module.exports = new event;