function do_a(){
  console.log( '`do_a`: this comes out first');
}

function do_b(){
  console.log( '`do_b`: this comes out later' );
}

do_a();
do_b();