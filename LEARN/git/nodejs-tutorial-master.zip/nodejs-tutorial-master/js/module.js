var logger = require('logger');
logger.log('A test log message');
logger.warn('A test warning message');
logger.error('A test error message');