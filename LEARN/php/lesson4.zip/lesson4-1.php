<?php
//装载模板文件
include_once("wx_tpl.php");

//获取微信发送数据
$postStr = $GLOBALS["HTTP_RAW_POST_DATA"];

  //返回回复数据
if (!empty($postStr)){
          
    	//解析数据
          $postObj = simplexml_load_string($postStr, 'SimpleXMLElement', LIBXML_NOCDATA);
    	//发送消息方ID
          $fromUsername = $postObj->FromUserName;
    	//接收消息方ID
          $toUsername = $postObj->ToUserName;
   	 //消息类型
          $form_MsgType = $postObj->MsgType;
          


  	//图片消息
          if($form_MsgType=="image")
          {
            //获取发送的图片URL
            $from_PicUrl=$postObj->PicUrl;
             //创建新图片的名称
            $filename=$fromUsername.date("YmdHis").".jpg";
            //建立抓取图片类
            $f = new SaeFetchurl();
            //抓取图片
            $res = $f->fetch($from_PicUrl);
            //如果抓取到图片
            if($f->errno() == 0) 
            {
              //新建存储类
              $s = new SaeStorage();
              //写入图片
	      $s->write( 'weixincourse' , $filename , $res );
              if($s->errno()==0)
              {
                //成功提示
                $msgType = "text";
                $resultStr = sprintf($textTpl, $fromUsername, $toUsername, $time, $msgType, "图片上传成功");
                echo $resultStr;
              }
              else
              {
               //失败提示
                $msgType = "text";
                $resultStr = sprintf($textTpl, $fromUsername, $toUsername, $time, $msgType, "图片保存失败");
                echo $resultStr;
              }
            }
            else
            {
              //失败提示
              $msgType = "text";
              $resultStr = sprintf($textTpl, $fromUsername, $toUsername, $time, $msgType, "图片上传失败");
              echo $resultStr;
            }
            exit;                                   
          }
  	//文字消息
          if($form_MsgType=="text")
          {
              
           //获取用户发送的文字内容
            $form_Content = trim($postObj->Content);

              
              
	   //如果发送内容不是空白回复用户相同的文字内容
 	    if(!empty($form_Content))
            {
            
              //回复菜谱类别
                if($form_Content=="菜谱")
                {
                	
                  $return_str="请输入字母编码浏览相应菜品：\n\n";
                  $return_arr=array("lc.冷菜\n","hb.杭帮菜\n","sk.烧烤\n","wp.外婆烧\n","ml.麻辣\n","rc.热菜\n","tp.甜品");
                  $return_str.=implode("",$return_arr);
                  $msgType = "text";
                  $resultStr = sprintf($textTpl, $fromUsername, $toUsername, $time, $msgType, $return_str);
                  echo $resultStr;
                  exit;                                   
                
                }
              //回复菜谱详情 外婆烧
              	if($form_Content=="wp")
                {
                  $resultStr="<xml>\n
                  <ToUserName><![CDATA[".$fromUsername."]]></ToUserName>\n
                  <FromUserName><![CDATA[".$toUsername."]]></FromUserName>\n
                  <CreateTime>".time()."</CreateTime>\n
                  <MsgType><![CDATA[news]]></MsgType>\n
                  <ArticleCount>10</ArticleCount>\n
                  <Articles>\n";                  
                  //菜谱详情数组  
                  $return_arr=array(
                  	array(
                        "外婆烧",
                        "http://weixincourse-weixincourse.stor.sinaapp.com/wp1.png",
                        "http://www.weixin.fm"
                        ),
                  	array(
                        "开心土豆（16元）",
                        "http://weixincourse-weixincourse.stor.sinaapp.com/wp2.png",
                        "http://www.weixin.fm"
                        ),
                  	array(
                        "铁板虾（36元）",
                        "http://weixincourse-weixincourse.stor.sinaapp.com/wp2.png",
                        "http://www.weixin.fm"
                        ),
                  	array(
                        "酸辣汤（16元）",
                        "http://weixincourse-weixincourse.stor.sinaapp.com/wp2.png",
                        "http://www.weixin.fm"
                        ),
                  	array(
                        "鱼香茄子（12元）",
                        "http://weixincourse-weixincourse.stor.sinaapp.com/wp2.png",
                        "http://www.weixin.fm"
                        ),
                  	array(
                        "麻辣豆腐（16元）",
                        "http://weixincourse-weixincourse.stor.sinaapp.com/wp2.png",
                        "http://www.weixin.fm"
                        ),
                  	array(
                        "茶香鸡（36元）",
                        "http://weixincourse-weixincourse.stor.sinaapp.com/wp2.png",
                        "http://www.weixin.fm"
                        ),
                  	array(
                        "五香牛肉（40元）",
                        "http://weixincourse-weixincourse.stor.sinaapp.com/wp2.png",
                        "http://www.weixin.fm"
                        ),
                   	array(
                        "风沙羊排（45元）",
                        "http://weixincourse-weixincourse.stor.sinaapp.com/wp2.png",
                        "http://www.weixin.fm"
                        ),
                   	array(
                        "下一页请输入“w2”，返回请输入“菜谱”",
                        "http://weixincourse-weixincourse.stor.sinaapp.com/wp2.png",
                        "http://www.weixin.fm"
                        )
                  
                  );
                  //数组循环转化
                  foreach($return_arr as $value)
                  {
                    $resultStr.="<item>\n
                    <Title><![CDATA[".$value[0]."]]></Title> \n
                    <Description><![CDATA[]]></Description>\n
                    <PicUrl><![CDATA[".$value[1]."]]></PicUrl>\n
                    <Url><![CDATA[".$value[2]."]]></Url>\n
                    </item>\n";
                  }
                  $resultStr.="</Articles>\n
                  <FuncFlag>0</FuncFlag>\n
                  </xml>";                
                  echo $resultStr;
                  exit;
                }
                
              //表情回复歌曲
              if($form_Content=="/::)")
              {
              	
		$msgType = "music";
                $resultStr = sprintf(
               		 $musicTpl, 
                         $fromUsername, 
                         $toUsername, 
                         $time, 
                         $msgType, 
                         "我的歌声里",
                         "曲婉婷",
                         "http://weixincourse-weixincourse.stor.sinaapp.com/mysongs.aac",
                         "http://weixincourse-weixincourse.stor.sinaapp.com/mysongs.mp3");
                echo $resultStr;
                exit;
							            
              }
              
              //默认回复
                $msgType = "text";
                $resultStr = sprintf($textTpl, $fromUsername, $toUsername, $time, $msgType, "请输入菜谱点菜");
                echo $resultStr;
                exit;                                   
            }
            //否则提示输入
            else
            {
                $msgType = "text";
                $resultStr = sprintf($textTpl, $fromUsername, $toUsername, $time, $msgType, "请输入些什么吧……");
                echo $resultStr;
                exit;                                   
            }          
          }
        
          
    	//事件消息
          if($form_MsgType=="event")
          {
            //获取事件类型
            $form_Event = $postObj->Event;
            //订阅事件
            if($form_Event=="subscribe")
            {
 
 
             //回复欢迎图文菜单
              $resultStr="<xml>\n
              <ToUserName><![CDATA[".$fromUsername."]]></ToUserName>\n
              <FromUserName><![CDATA[".$toUsername."]]></FromUserName>\n
              <CreateTime>".time()."</CreateTime>\n
              <MsgType><![CDATA[news]]></MsgType>\n
              <ArticleCount>5</ArticleCount>\n
              <Articles>\n";
              
              //添加封面图文消息
              $resultStr.="<item>\n
              <Title><![CDATA[国内最专业的微信教程]]></Title> \n
              <Description><![CDATA[]]></Description>\n
              <PicUrl><![CDATA[http://weixincourse-weixincourse.stor.sinaapp.com/Snip20130403_8.jpg]]></PicUrl>\n
              <Url><![CDATA[http://mp.weixin.qq.com/mp/appmsg/show?__biz=MjM5MjgwNjgwMA==&appmsgid=10000169&itemidx=1]]></Url>\n
              </item>\n";
              
              //添加4条列表图文消息
              $resultStr.="<item>\n
              <Title><![CDATA[教程大纲]]></Title> \n
              <Description><![CDATA[]]></Description>\n
              <PicUrl><![CDATA[http://weixincourse-weixincourse.stor.sinaapp.com/Snip20130403_14.jpg]]></PicUrl>\n
              <Url><![CDATA[http://ztalk.sinaapp.com]]></Url>\n
              </item>\n";
              
              $resultStr.="<item>\n
              <Title><![CDATA[报名培训]]></Title> \n
              <Description><![CDATA[]]></Description>\n
              <PicUrl><![CDATA[http://weixincourse-weixincourse.stor.sinaapp.com/Snip20130504_8.png]]></PicUrl>\n
              <Url><![CDATA[http://mp.weixin.qq.com/mp/appmsg/show?__biz=MjM5MjgwNjgwMA==&appmsgid=10000169&itemidx=1]]></Url>\n
              </item>\n";
              
              $resultStr.="<item>\n
              <Title><![CDATA[关于老贼]]></Title> \n
              <Description><![CDATA[]]></Description>\n
              <PicUrl><![CDATA[http://weixincourse-weixincourse.stor.sinaapp.com/lz.jpg]]></PicUrl>\n
              <Url><![CDATA[http://mp.weixin.qq.com/mp/appmsg/show?__biz=MjM5MTcyMDAyMQ==&appmsgid=10000054&itemidx=1]]></Url>\n
              </item>\n";
              
              $resultStr.="<item>\n
              <Title><![CDATA[联系老贼]]></Title> \n
              <Description><![CDATA[]]></Description>\n
              <PicUrl><![CDATA[http://weixincourse-weixincourse.stor.sinaapp.com/Snip20130403_19.jpg]]></PicUrl>\n
              <Url><![CDATA[http://mp.weixin.qq.com/mp/appmsg/show?__biz=MjM5MTcyMDAyMQ==&appmsgid=10000054&itemidx=1]]></Url>\n
              </item>\n";
              
              $resultStr.="</Articles>\n
              <FuncFlag>0</FuncFlag>\n
              </xml>";
                        
              /*
              //回复欢迎文字消息
              $msgType = "text";
              $contentStr = "感谢您关注公众平台教程！[愉快]\n\n想学公众平台使用的朋友请输入“跟我学”！[玫瑰]";
              $resultStr = sprintf($textTpl, $fromUsername, $toUsername, time(), $msgType, $contentStr);
              */
              
              echo $resultStr;
              exit;
	      
            }
          
          }
          
  }
  else 
  {
          echo "";
          exit;
  }

?>